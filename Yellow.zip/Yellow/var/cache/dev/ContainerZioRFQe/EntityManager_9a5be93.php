<?php

namespace ContainerZioRFQe;
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'persistence'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'Persistence'.\DIRECTORY_SEPARATOR.'ObjectManager.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManagerInterface.php';
include_once \dirname(__DIR__, 4).''.\DIRECTORY_SEPARATOR.'vendor'.\DIRECTORY_SEPARATOR.'doctrine'.\DIRECTORY_SEPARATOR.'orm'.\DIRECTORY_SEPARATOR.'lib'.\DIRECTORY_SEPARATOR.'Doctrine'.\DIRECTORY_SEPARATOR.'ORM'.\DIRECTORY_SEPARATOR.'EntityManager.php';

class EntityManager_9a5be93 extends \Doctrine\ORM\EntityManager implements \ProxyManager\Proxy\VirtualProxyInterface
{
    /**
     * @var \Doctrine\ORM\EntityManager|null wrapped object, if the proxy is initialized
     */
    private $valueHolder678fc = null;

    /**
     * @var \Closure|null initializer responsible for generating the wrapped object
     */
    private $initializerf8f5e = null;

    /**
     * @var bool[] map of public properties of the parent class
     */
    private static $publicPropertiesb888d = [
        
    ];

    public function getConnection()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getConnection', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getConnection();
    }

    public function getMetadataFactory()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getMetadataFactory', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getMetadataFactory();
    }

    public function getExpressionBuilder()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getExpressionBuilder', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getExpressionBuilder();
    }

    public function beginTransaction()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'beginTransaction', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->beginTransaction();
    }

    public function getCache()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getCache', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getCache();
    }

    public function transactional($func)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'transactional', array('func' => $func), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->transactional($func);
    }

    public function wrapInTransaction(callable $func)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'wrapInTransaction', array('func' => $func), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->wrapInTransaction($func);
    }

    public function commit()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'commit', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->commit();
    }

    public function rollback()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'rollback', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->rollback();
    }

    public function getClassMetadata($className)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getClassMetadata', array('className' => $className), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getClassMetadata($className);
    }

    public function createQuery($dql = '')
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'createQuery', array('dql' => $dql), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->createQuery($dql);
    }

    public function createNamedQuery($name)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'createNamedQuery', array('name' => $name), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->createNamedQuery($name);
    }

    public function createNativeQuery($sql, \Doctrine\ORM\Query\ResultSetMapping $rsm)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'createNativeQuery', array('sql' => $sql, 'rsm' => $rsm), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->createNativeQuery($sql, $rsm);
    }

    public function createNamedNativeQuery($name)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'createNamedNativeQuery', array('name' => $name), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->createNamedNativeQuery($name);
    }

    public function createQueryBuilder()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'createQueryBuilder', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->createQueryBuilder();
    }

    public function flush($entity = null)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'flush', array('entity' => $entity), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->flush($entity);
    }

    public function find($className, $id, $lockMode = null, $lockVersion = null)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'find', array('className' => $className, 'id' => $id, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->find($className, $id, $lockMode, $lockVersion);
    }

    public function getReference($entityName, $id)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getReference', array('entityName' => $entityName, 'id' => $id), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getReference($entityName, $id);
    }

    public function getPartialReference($entityName, $identifier)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getPartialReference', array('entityName' => $entityName, 'identifier' => $identifier), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getPartialReference($entityName, $identifier);
    }

    public function clear($entityName = null)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'clear', array('entityName' => $entityName), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->clear($entityName);
    }

    public function close()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'close', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->close();
    }

    public function persist($entity)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'persist', array('entity' => $entity), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->persist($entity);
    }

    public function remove($entity)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'remove', array('entity' => $entity), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->remove($entity);
    }

    public function refresh($entity)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'refresh', array('entity' => $entity), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->refresh($entity);
    }

    public function detach($entity)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'detach', array('entity' => $entity), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->detach($entity);
    }

    public function merge($entity)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'merge', array('entity' => $entity), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->merge($entity);
    }

    public function copy($entity, $deep = false)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'copy', array('entity' => $entity, 'deep' => $deep), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->copy($entity, $deep);
    }

    public function lock($entity, $lockMode, $lockVersion = null)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'lock', array('entity' => $entity, 'lockMode' => $lockMode, 'lockVersion' => $lockVersion), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->lock($entity, $lockMode, $lockVersion);
    }

    public function getRepository($entityName)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getRepository', array('entityName' => $entityName), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getRepository($entityName);
    }

    public function contains($entity)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'contains', array('entity' => $entity), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->contains($entity);
    }

    public function getEventManager()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getEventManager', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getEventManager();
    }

    public function getConfiguration()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getConfiguration', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getConfiguration();
    }

    public function isOpen()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'isOpen', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->isOpen();
    }

    public function getUnitOfWork()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getUnitOfWork', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getUnitOfWork();
    }

    public function getHydrator($hydrationMode)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getHydrator($hydrationMode);
    }

    public function newHydrator($hydrationMode)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'newHydrator', array('hydrationMode' => $hydrationMode), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->newHydrator($hydrationMode);
    }

    public function getProxyFactory()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getProxyFactory', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getProxyFactory();
    }

    public function initializeObject($obj)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'initializeObject', array('obj' => $obj), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->initializeObject($obj);
    }

    public function getFilters()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'getFilters', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->getFilters();
    }

    public function isFiltersStateClean()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'isFiltersStateClean', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->isFiltersStateClean();
    }

    public function hasFilters()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'hasFilters', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return $this->valueHolder678fc->hasFilters();
    }

    /**
     * Constructor for lazy initialization
     *
     * @param \Closure|null $initializer
     */
    public static function staticProxyConstructor($initializer)
    {
        static $reflection;

        $reflection = $reflection ?? new \ReflectionClass(__CLASS__);
        $instance   = $reflection->newInstanceWithoutConstructor();

        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $instance, 'Doctrine\\ORM\\EntityManager')->__invoke($instance);

        $instance->initializerf8f5e = $initializer;

        return $instance;
    }

    protected function __construct(\Doctrine\DBAL\Connection $conn, \Doctrine\ORM\Configuration $config, \Doctrine\Common\EventManager $eventManager)
    {
        static $reflection;

        if (! $this->valueHolder678fc) {
            $reflection = $reflection ?? new \ReflectionClass('Doctrine\\ORM\\EntityManager');
            $this->valueHolder678fc = $reflection->newInstanceWithoutConstructor();
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);

        }

        $this->valueHolder678fc->__construct($conn, $config, $eventManager);
    }

    public function & __get($name)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, '__get', ['name' => $name], $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        if (isset(self::$publicPropertiesb888d[$name])) {
            return $this->valueHolder678fc->$name;
        }

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder678fc;

            $backtrace = debug_backtrace(false, 1);
            trigger_error(
                sprintf(
                    'Undefined property: %s::$%s in %s on line %s',
                    $realInstanceReflection->getName(),
                    $name,
                    $backtrace[0]['file'],
                    $backtrace[0]['line']
                ),
                \E_USER_NOTICE
            );
            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder678fc;
        $accessor = function & () use ($targetObject, $name) {
            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __set($name, $value)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, '__set', array('name' => $name, 'value' => $value), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder678fc;

            $targetObject->$name = $value;

            return $targetObject->$name;
        }

        $targetObject = $this->valueHolder678fc;
        $accessor = function & () use ($targetObject, $name, $value) {
            $targetObject->$name = $value;

            return $targetObject->$name;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = & $accessor();

        return $returnValue;
    }

    public function __isset($name)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, '__isset', array('name' => $name), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder678fc;

            return isset($targetObject->$name);
        }

        $targetObject = $this->valueHolder678fc;
        $accessor = function () use ($targetObject, $name) {
            return isset($targetObject->$name);
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $returnValue = $accessor();

        return $returnValue;
    }

    public function __unset($name)
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, '__unset', array('name' => $name), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        $realInstanceReflection = new \ReflectionClass('Doctrine\\ORM\\EntityManager');

        if (! $realInstanceReflection->hasProperty($name)) {
            $targetObject = $this->valueHolder678fc;

            unset($targetObject->$name);

            return;
        }

        $targetObject = $this->valueHolder678fc;
        $accessor = function () use ($targetObject, $name) {
            unset($targetObject->$name);

            return;
        };
        $backtrace = debug_backtrace(true, 2);
        $scopeObject = isset($backtrace[1]['object']) ? $backtrace[1]['object'] : new \ProxyManager\Stub\EmptyClassStub();
        $accessor = $accessor->bindTo($scopeObject, get_class($scopeObject));
        $accessor();
    }

    public function __clone()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, '__clone', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        $this->valueHolder678fc = clone $this->valueHolder678fc;
    }

    public function __sleep()
    {
        $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, '__sleep', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;

        return array('valueHolder678fc');
    }

    public function __wakeup()
    {
        \Closure::bind(function (\Doctrine\ORM\EntityManager $instance) {
            unset($instance->config, $instance->conn, $instance->metadataFactory, $instance->unitOfWork, $instance->eventManager, $instance->proxyFactory, $instance->repositoryFactory, $instance->expressionBuilder, $instance->closed, $instance->filterCollection, $instance->cache);
        }, $this, 'Doctrine\\ORM\\EntityManager')->__invoke($this);
    }

    public function setProxyInitializer(\Closure $initializer = null) : void
    {
        $this->initializerf8f5e = $initializer;
    }

    public function getProxyInitializer() : ?\Closure
    {
        return $this->initializerf8f5e;
    }

    public function initializeProxy() : bool
    {
        return $this->initializerf8f5e && ($this->initializerf8f5e->__invoke($valueHolder678fc, $this, 'initializeProxy', array(), $this->initializerf8f5e) || 1) && $this->valueHolder678fc = $valueHolder678fc;
    }

    public function isProxyInitialized() : bool
    {
        return null !== $this->valueHolder678fc;
    }

    public function getWrappedValueHolderValue()
    {
        return $this->valueHolder678fc;
    }
}

if (!\class_exists('EntityManager_9a5be93', false)) {
    \class_alias(__NAMESPACE__.'\\EntityManager_9a5be93', 'EntityManager_9a5be93', false);
}
